/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer;
import javax.swing.*; // impoting swing 
/**
 *
 * @author Arnold
 */
public class Customer {



// my varibles 
        protected String name;
        protected String contact;
        protected double productprice;
        protected int months;
        protected String pp;
        protected String nrmonths;
        protected double repayments;
        protected double Totaldue;

    
// my getters and setters 
        public String getName() {
            name = JOptionPane.showInputDialog("Please enter the customer name");
        return name;
    }

    public String getContact() {
            contact = JOptionPane.showInputDialog("Please enter the customer contact number");
        return contact;
    }

    public double getProductprice() {
            pp = JOptionPane.showInputDialog("Please enter the price of the product");
            productprice = Double.parseDouble(pp);
        return productprice;
    }

    public int getMonths() {
            nrmonths = JOptionPane.showInputDialog("Please eneter the number of repayment months");
            months = Integer.parseInt(nrmonths);
            
        return months;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void setProductprice(int productprice) {
        this.productprice = productprice;
    }

    public void setMonths(int months) {
        this.months = months;
    }
    //----------------------------------------------------------------------------------------------------> // my main method 
    
    public static void main(String[] args) {
   
     Customer_Finance person = new Customer_Finance();  // creates new entry
        
    } 
    
    //------------------------------------------------------------------------------------------------------> // method calculates repayments 
    
    public void  calculate_repayment (){
         
         repayments = (Totaldue/this.months);
         
    }

  

   
    
}
