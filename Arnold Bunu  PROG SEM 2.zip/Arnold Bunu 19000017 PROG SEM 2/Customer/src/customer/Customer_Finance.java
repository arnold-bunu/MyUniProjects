/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer;
import javax.swing.JOptionPane;
/**
 *
 * @author Arnold
 */
public class Customer_Finance extends Finance_Period { // new subclass
    
    Customer_Finance(){
        super.getName();
        super.getContact();
        super.getProductprice();
        super.getMonths();
        
        
        
        
        super.interest();
        super.calculate_repayment();
       JOptionPane.showMessageDialog(null, "customer name: " + name + "\n"      // output message 
                                        + "Customer Contact: " + contact + "\n"
                                        + "product price: R" + productprice + "\n"
                                        + "number of months: " + months + "\n" 
                                        +"repayments are: R" + repayments + "\n"
                                        + "Total due: R" + Totaldue);
               
    }
    
}
