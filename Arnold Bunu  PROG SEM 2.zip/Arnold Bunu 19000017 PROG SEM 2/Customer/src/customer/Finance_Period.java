/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customer;
// this is my subclass 
/**
 *
 * @author Arnold
 */
public class Finance_Period extends Customer{ // new subclass
    
//---------------------------------------------------------------------------------------> main method    
    public static void main(String[] args) {
        Finance_Period period = new Finance_Period();
        Customer customer = period;
        Customer.main(args);
        
    }
    

//-----------------------------------------------------------------------------------------> method calculates interest
    public  void interest() {
            final int max = 12;
        if (months > max) {
            System.out.print("Please enter months below 12");
        }
           if (months > 3){
        // pays interest
         Totaldue = productprice + (productprice*0.25);
    }
    else{
        // no interest
         Totaldue = productprice;
    }
}

    
    
}