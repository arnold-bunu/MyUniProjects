/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question2;
import java.util.Scanner;
/**
 *
 * @author Arnold
 */
public class scrabble {
    // here are my variables 
    protected static String player_1;
    protected static String player_2;
    public static String used = "";
    protected static String alphabet = "a b c d e f g h i j k l m n o p q r s t u v w x y z ";
    protected static int playerNum = 1;
    protected static String turn; 
    protected static boolean availableLetters = true;
    protected static String unavailabeLetters = "";
    protected static int player1Score = 0;
    protected static int player2Score = 0;
    
    

   //---------------------------------------------------------------------------------------> Here is my main method
    
    public static void main(String[] args) {
        
        System.out.print("Welcome to the WORD WARS game." + // welcome message 
                  "\n" + 
                "\n" + "Press (1) To start the game." +  // prompts user to start the game 
                "\n" +
                    "\n" + "Press any other key to exit the game" + 
                    "\n" + "Enter your selection: ");
      
        if ( new Scanner(System.in).next().equalsIgnoreCase("1"))   // checks the input, if its one carry on
        {
            System.out.println("****************************************");
            
            System.out.print("Enter player 1 name: ");
            player_1 = new Scanner(System.in).next();  // player one to input name 
            System.out.print("Enter player 2 name: ");
            player_2 = new Scanner (System.in).next();   // player two to input name 
            System.out.println("LETS PLAY WORD WARS!!!");
            play();     // this calls the play method which gets the game going 
            finalScore();
            playAgain();
        }
        
        else {
            System.out.println("Thank you! Good Bye...");
            System.exit(0);  // if theres invalid input or user doesnt opt to start, the file stops running
        }
       
    }
//------------------------------------------------------------------------------------------------------------------> // play game method
    private static void play() {
        while(!used.equals("???")){  // sentinal value ???, if its not entered we loop untill it is.
        
        turn();   // calls method to switch turns after each other 
        
        System.out.println("Alphabet letters left: " + availableLetters() );  // prints out the available letters including the method that updates the ist 
        System.out.println( turn + " enter your word: ");  
        used = new Scanner (System.in).next();
        
        validate();  // this asks the players if they both agree on the word 
        
    }
    
    }
    
   //-----------------------------------------------------------------------------------------------------------------> // method that updates available letters list
    
    private static String availableLetters() 
    {
        if(availableLetters == true) // boolean, while its true, the next bloxk will excecute 
        {
           for(int i=0; i<alphabet.toCharArray().length;i++)  
         {
            if(used.contains((alphabet.toCharArray()[i]+"")))  
            {                                                                                   // this block collects and stores words and letters that were used. it then removes the used letters from the alphabet list
                unavailabeLetters += (alphabet.toCharArray()[i]+"");
                alphabet = alphabet.replace((alphabet.toCharArray()[i]+""), " ");
            }
          }
        }
        else
        {
            System.out.print("\nYOU ENTERED A WORD THAT CONTAINS A LETTER THAT IS USED OR NOT VALID. PLEASE ENTER ANOTHER WORD!"); // error message for repeating letters or invalid words
            availableLetters = true;
        }
        return alphabet;
    }
   //------------------------------------------------------------------------------------------------------------------> // method that keeps vowels 

    private static void vowels() {
        String vowels = "a e i o u";
        
        for (int i = 0 ; i <used.toCharArray().length;i++) {
            
            if (vowels.contains((used.toCharArray()[i]+""))) {
                used = used.replace((used.toCharArray()[i] + ""), "");
            }
        }
            
        
    }
//------------------------------------------------------------------------------------------------------------------------> // method that makes players alternate 
    private static void turn() {
        if(playerNum == 1){
            turn = player_1;
            playerNum += 1;
        }
        else {
            turn = player_2;
            playerNum -=1; 
        }
    }
//--------------------------------------------------------------------------------------------------------------------------> // method that validates the input 
     private static void validate() 
    {
        System.out.print("\nEnter (y) yes if both players agree on the word: ");
        if (new Scanner(System.in).next().equalsIgnoreCase("y"))
        {
            searchunavailabeLetters();
            vowels();
            trackScore();
            
        }
        else
        {
          used = "";  
        }
    }
//---------------------------------------------------------------------------------------------------------------------------->// method searches for unavailable letters
    private static void searchunavailabeLetters() {
        
        for(int i=0; i< unavailabeLetters.toCharArray().length;i++)
        {
            if(used.contains((unavailabeLetters.toCharArray()[i]+"")))
            {
                availableLetters = false;
            }
        }
    }
//-----------------------------------------------------------------------------------------------------------------------------> 
    
       private static void trackScore() 
    {
       //check name of current player
       if(turn.equals(player_1)&& !used.equals("???"))
       {
           player1Score += 1; 
       } 
       if(turn.equals(player_2)&& !used.equals("???"))
       {
           player2Score += 1; 
       } 
    }
//------------------------------------------------------------------------------------------------------------------------------->
        
        private static void finalScore() 
    {
    
        // if player one wins
        if(player1Score > player2Score)
        {
            System.out.println("WINNER OF THE GAME IS: "+ player_1 + " with a Score of " + player1Score);
        }
            
        // if player 2 wins
        else{
            System.out.println("WINNER OF THE GAME IS: "+ player_2+ " with a Score of " + player2Score);
        }
        
        // if its a tie
        if(player1Score == player2Score)
        {
           System.out.println("ITS A TIE!! WINNERS ARE: "+ player_1 +" and "+ player_2);
        }
        System.out.println("YOUR NAME HAS BEEN SAVED TO THE HALL OF FAME!!");
        System.out.println("THE GAME IS NOW OVER. THANKYOU FOR PLAYING WORD WARS!!");
        
    }
        
        
    
//-------------------------------------------------------------------------------------------------------------------------------->

 private static void playAgain() 
    {
        String again = "y";
        while("y".equals(again))
        {
            System.out.print("Would you like to play again? y/n: ");
            again = new Scanner(System.in).next();
            
            if (new Scanner(System.in).next().equalsIgnoreCase("y")) {
            play();
            }
            else {
                System.exit(0);
            }
        }
    }        

}
