/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assq2;
import javax.swing.*; 
import java.util.Scanner;
/**
 *
 * @author Arnold
 */
public class AssQ2 {
    
    // This is where I name all of my class variables 
   private int studNo;
    private String studName;
    private String studHouse;
    
    //Here is my constructor
    public AssQ2 (int stNo, String stName, String stHouse) {
        this.studNo = stNo;
        this.studName = stName;
        this.studHouse = stHouse;
    }
 
    // I have made gets and sets 
    public int getStudNo() {
        return studNo;
    }

    public void setStudNo(int studNo) {
        this.studNo = studNo;
    }

    public String getStudName() {
        return studName;
    }

    public void setStudName(String studName) {
        this.studName = studName;
    }



    public String getStudHouse() {
        return studHouse;
    }

    public void setStudHouse(String studHouse) {
        this.studHouse = studHouse;
    }  
    
       // Static method to construct a string  with all the output needed as per assignment question
       public static String getStudent(int stNo , String stName , String stHouse) {
   
        return ( "\n" +stName  + " assigned to the " + stHouse + " house with student number " + 
                  stHouse) + Integer.toString(stNo);
       }
   
    public static void main(String[] args) {
        
        final int STUDENTS = 3; // The maximun number of students we have to capture 
        final int HOUSE = 3;  // The number of houses we have 
        final int NUMBER_LIMIT = 10000; // The maximum value for the random integer 
        final String [] order = { "first", "second", "third"};
        final String HEADER =  "SCHOOL HOUSE ASSIGNMENT";
        final String ASTERIX = "**********************************";
        Scanner input = new Scanner(System.in);
        AssQ2[] stud = new AssQ2[STUDENTS];
        
        
        String COLORS[] = {"WHITE", "BLUE", "RED"}; // This is the rray with the house names 
        String studentName[] = new String[STUDENTS];
        int studentNumber[] = new int[STUDENTS];
        String studentColour[] = new String[STUDENTS];
        
        JPanel jPanel = new JPanel();
        
        JTextField jName = new JTextField(20);    // This is the tect field where the user will input the student name, field size is 20 
        jPanel.add(jName); 
        
                boolean didCancel = false;  // This checks if the user cancelled 
        int counter = 0;            // General purpose counter 
        String outputString = ""; 
       
        
  do {

            int result = JOptionPane.showConfirmDialog(null, jPanel, "Please enter the " + order[counter]+  " student name " ,
                                                       JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                // Generate random student number 
                int randStudNo = (int)(Math.random() * NUMBER_LIMIT);
                // Generates random hoouse for each student 
                String randHouse = COLORS[(int)(Math.random() * HOUSE)];
                // Populating the student object using cunstructors 
                stud[counter] = new AssQ2(randStudNo,jName.getText(),randHouse);
                // Blank text field for the next student 
                jName.setText("");
               
            }
            else {
                // User pressed cancel 
                didCancel = true;
            }
        // Increments the counter to the next student 
            counter++;
        } while ((counter < STUDENTS) && (didCancel == false));
        
    // This is the output     
        if (didCancel == false) {
            for (counter = 0; counter < STUDENTS; counter++) {
   
                AssQ2 s = stud[counter]; 
                // This is the student information we will be displaying 
                outputString = outputString + AssQ2.getStudent(s.getStudNo(),s.getStudName(),s.getStudHouse());
            }
            // Student details output
            JOptionPane.showMessageDialog(null, HEADER + "\n" + ASTERIX + "\n" + outputString,"School House Assignment",JOptionPane.INFORMATION_MESSAGE);
        }
        else {
            // This is the cancelation message 
           JOptionPane.showMessageDialog(null, "Successfully cancelled","CANCELLED",JOptionPane.INFORMATION_MESSAGE); 
        }
        }

       
       
       
       
      
       
       
       

       
    }
        

    
    

