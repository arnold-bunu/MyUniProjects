package question.pkg3.pkgfinal;
import javax.swing.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class Question3Final {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
        // Here are my local variables 
        String result;         
        String prompt;        
        int choice;            
        boolean fault;         
        

        
        // DELIVERY_DETAILS OBJECT (new delivery)
        Delivery_Details pkg = new Delivery_Details();
        
        // This is the town input
        fault = true;   
        do {
        // this is the fist user input window
            prompt = "Select the town the parcel will be delivered to";
            for (int counter = 0; counter < Delivery_Details.TOWNS.length; counter++) {
                prompt = prompt + "\n" + (counter + 1) + ") " + Delivery_Details.TOWNS[counter];
            }
            result = JOptionPane.showInputDialog(null,prompt);
            
            // this validates the return value
            if (result == null) {
                System.exit(0);
            }
            if (!result.isEmpty()) { 
               try {                             
                    choice = Integer.parseInt(result.trim()); // converts srting to int
                    if ((choice <= Delivery_Details.TOWNS.length) && (choice > 0)) {
                        pkg.setTown(choice-1); // The selects the town 
                        fault = false; // input is valid
                    }  
                    else {
                        ErrorMessage();
                    }
               }
               catch (NumberFormatException nfe) {  
                   ErrorMessage();
               }
            }
            else {
                    ErrorMessage();
            }    
        } while (fault);

        // this is the weight input window
        fault = true;   
        do {
        // this is the second user input window
            prompt = "Select the weight of the parcel to be delivered to: " + Delivery_Details.TOWNS[pkg.getTown()];
            for (int counter = 0; counter < Delivery_Details.PACKAGES.length; counter++) {
                prompt = prompt + "\n" + (counter + 1) + ") " + Delivery_Details.PACKAGES[counter];
            }
            result = JOptionPane.showInputDialog(null,prompt);
            
            // validate the town 
            if (result == null) {
                System.exit(0);
            }
            if (!result.isEmpty()) { 
               try {                            
                    choice = Integer.parseInt(result.trim()); 
                    if ((choice <= Delivery_Details.COSTS.length) && (choice > 0)) {
                        pkg.setWeight(choice - 1); // sets the wheight
                        pkg.setPrice(choice - 1);  // sets the price 
                        fault = false; // validates input 
                    }  
                    else {
                        ErrorMessage();
                    }
               }
               catch (NumberFormatException nfe) {  
                   ErrorMessage();
               }
            }
            else {
                ErrorMessage();
            }
        } while (fault);
        // This is th ecourier window  
        fault = true;   
        do {
        // This is the user input window 
            prompt = "Select the courier company to deliver the parcel weight of " 
                    + Delivery_Details.PACKAGES[pkg.getWeight()] 
                    + " to " + Delivery_Details.TOWNS[pkg.getTown()];
            for (int counter = 0; counter < Delivery_Details.COURIERS.length; counter++) {
                prompt = prompt + "\n" + (counter + 1) + ") " + Delivery_Details.COURIERS[counter];
            }
            result = JOptionPane.showInputDialog(null,prompt);
            
            // checks if user cancelled 
            if (result == null) {
                System.exit(0);
            }
            if (!result.isEmpty()) { 
               try {                            
                    choice = Integer.parseInt(result.trim()); 
                    if ((choice <= Delivery_Details.COURIERS.length) && (choice > 0)) {
                        pkg.setDeliveryCompany(choice - 1); // weight category gets set here 
                        fault = false; // validates input 
                    }  
                    else {
                        ErrorMessage();
                    }
               }
               catch (NumberFormatException nfe) { 
                   ErrorMessage();
               }
            }
            else {
                ErrorMessage();
            }
        } while (fault); 
         
       pkg.Totals();
       DeliveryReport(pkg);
    }
    // this next block outputs the delivery details 
    public static void DeliveryReport(Delivery_Details thePkg) {
                DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date dateObject = new Date();
        System.out.println("DELIVERY REPORT - Created on " + dateFormat.format(dateObject));
        System.out.println("***********************************************");
        System.out.println("TOWN:\t\t" + Delivery_Details.TOWNS[thePkg.getTown()]);
        System.out.println("WEIGHT:\t\t" + Delivery_Details.PACKAGES[thePkg.getWeight()]);
        System.out.println("PRICE:\t\tR " + (double) Delivery_Details.COSTS[thePkg.getPrice()]);
        System.out.println("VAT (14%):\tR " + thePkg.getVat());
        System.out.println("TOTAL DUE:\tR " + thePkg.getTotal());
        System.out.println("COURIER:\t" + Delivery_Details.COURIERS[thePkg.getDeliveryCompany()]);
        System.out.println("***********************************************");
    }
      public static void ErrorMessage (){
          JOptionPane.showMessageDialog(null, "Please select a valid integer","ERROR DETECTED",JOptionPane.ERROR_MESSAGE);
      }
}
