/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question.pkg3.pkgfinal;

/**
 *
 * @author Arnold
 */
public class Delivery_Details {


    public void setDeliveryCompany(int deliveryCompany) {
        this.deliveryCompany = deliveryCompany;
    }
    // here are my variables 
    private int town;  
    private int weight; 
    private int price;   
    private double vat;
    private double total;
    private int  deliveryCompany;
    
    // Here are the arrays 
    final static String[]   TOWNS       = {"Cape Town", "Pretoria", "Durban"}; // towns to choose from  
    final static String[]   COURIERS    = {"ABC Couriers","Fast Track", "Rest Assured"}; // couriers to choose from
    final static String[]   PACKAGES    = {"0kg — 4kg","5kg — 9kg","Over 10kg"}; // different weight classes 
    final static int[]      COSTS       = {300,500,700}; // different costs 
    
       // Here are my constant variables  
    final static double VAT = 0.14;
    
    // gets and sets 
        public int getTown() {
        return town;
    }

    
    public void setTown(int town) {
        this.town = town;
    }
    
    public int getWeight() {
        return weight;
    }


    public void setWeight(int weight) {
        this.weight = weight;
    }


    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public double getVat() {
        return vat;
    }

    public void setVat(double vat) {
        this.vat = vat;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public int getDeliveryCompany() {
        return deliveryCompany;
    }
    
    public void Totals() {
        this.setVat(COSTS[this.getPrice()] * VAT);
        this.setTotal(COSTS[this.getPrice()] + this.getVat());
    }
}
