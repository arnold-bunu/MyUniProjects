/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package question1;

import java.util.Scanner;

/**
 *
 * @author Arnold
 */
public class Question1 {
  public static void printDetails( String IDnumber, String Name, String Surname, double OGSal, double Salary){

        
        // this outputs the details report
            System.out.println("EMPLOYEE DETAILS REPORT");
            System.out.println("****************************");
            System.out.println("EMPLOYEE NUMBER:\t" + IDnumber );
            System.out.println("EMPLOYEE FIRST NAME:\t" + Name   );
            System.out.println("EMPOLYEE SURNAME:\t" + Surname );
            System.out.println("ORIGINAL SALARY:\tR " + OGSal );
            System.out.println("INCREASE SALARY:\tR " + Salary );
            System.out.println("INCREASED AMOUNT:\tR "  + (Salary * Details.RAISE));
            System.out.println("*******************************");
            System.out.println("Would you like to see the increased salary with deductions? Enter (1) to view the deductions report or any other key to exit.");
    
    }
  public static void printDeductions(double RAISE){
               
               // all necessary calculations  
                double tax = RAISE * Details.TAX;
                double aid = RAISE * Details.AID;
                double car = RAISE * Details.CAR;
                double uif = RAISE * Details.UIF;
                double finalpay = RAISE - tax - aid - car - uif;
               
        
    
   
    
    
        // this block shows the decutions report 
            System.out.println("EMPLOYEE DEDUCTIONS REPORT");
            
            System.out.println("****************************");
            
            System.out.println("SALARY:        " + " R " + RAISE);

            
            System.out.println("TAX:            " + "R " + tax);

            
            System.out.println("UIF:            " + "R " + aid);

            
            System.out.println("CAR ALLOWANCE:  " + "R " + car);

            
            System.out.println("UIF:            " + "R " + uif);

            
            System.out.println("TAKE HOME PAY:  " + "R " + finalpay);
            
            System.out.println("****************************");
             
            

         
        
    
   

 
    
}
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in); 
       Details Person = new Details ();
       double Sal;
       
          
            
            
        // this is where we will collect the users details

        System.out.print("Enter the employee number >> ");
        Person.setIDnumber(input.nextLine());
        System.out.print("Enter the employee name >> ");
        Person.setName(input.nextLine());
        System.out.print("Enter the employee surname >> ");
        Person.setSurname(input.nextLine());
        System.out.print("Enter the employee salary to be increased >> ");
        Sal = input.nextDouble();
        Person.setSalary(Sal);
        Person.setOGsal(Sal);

Person.getUpdatedSalary(); 
      
Question1.printDetails( Person.getIDnumber(), Person.getName(), Person.getSurname(),Person.getOGsal(),Person.getSalary());

String goon = input.next(); // checks to see if the deductions report should be opened 

if (goon.equals("1")){
 Question1.printDeductions(Person.getSalary());}
  else {
        System.exit(0);
    }
   
   System.out.println("Application Complete");
            
    
     
    }
    

    
   
         
}