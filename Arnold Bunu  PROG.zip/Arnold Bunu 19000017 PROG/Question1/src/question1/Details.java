
package question1;

/**
 *
 * @author Arnold
 */
public class Details {

 
    
    // This is where I'm going to declare my class variables
    
     private String IDnumber; 
     private String Name; 
     private  String Surname; 
     private double Salary;
     private double OGsal;
     
     
    // My constants will be declared here
            public final static double RAISE =  (0.10);
            public final static double TAX = (0.18);
            public final static double AID = (0.125);
            public final static double CAR = (0.08);
            public final static double UIF = (0.02);
            
            
     
    // Here are my getters and setters 
     
     public String getIDnumber() {
        return IDnumber;
    }

  
    public void setIDnumber(String IDnumber) {
        this.IDnumber = IDnumber;
    }

 
    public String getName() {
        return Name;
    }

   
    public void setName(String Name) {
        this.Name = Name;
    }

   
    public String getSurname() {
        return Surname;
    }

   
    public void setSurname(String Surname) {
        this.Surname = Surname;
    }

   
    public double getSalary() {
        return Salary;
    }

 
    public void setSalary(double Salary) {
        this.Salary = Salary;
    }

 
    public double getOGsal() {
        return OGsal;
    }

   
    public void setOGsal(double OGsal) {
        this.OGsal = OGsal;
    }
  //methods
    
    public void getUpdatedSalary(){
        this.Salary = this.Salary + (this.Salary * RAISE);
    }
    

}